package com.example.saborfy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaborfyApplicationTests {

	@Test
	void contextLoads() {
	}

}
